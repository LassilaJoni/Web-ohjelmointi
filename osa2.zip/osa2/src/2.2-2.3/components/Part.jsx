import React from 'react'
export default function Part ({ name, exercises, total })  {
    return (
      <>
        <p>
          {name} {exercises}
        </p>
      </>
    )
  }
