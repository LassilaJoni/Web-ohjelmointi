import React from 'react'

export default function Part ({ name, exercises })  {
    return (
      <>
        <p>
          {name} {exercises}
        </p>
      </>
    )
  }
