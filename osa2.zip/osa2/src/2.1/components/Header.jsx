import React from 'react'

export default function ({ name }) {
    return (
      <>
        <h1>{name}</h1>
      </>
    )
  }
